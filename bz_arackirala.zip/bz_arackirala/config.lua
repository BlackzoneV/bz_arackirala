Config = {}

--ARAÇ FİYATLARI
Config.ArabaSure 	= 60

Config.Panto		= 250
Config.Bmx			= 100

--PED MODELİ

Config.PedModel		= "s_m_y_valet_01"
Config.PedKordinat	= { x = -1021.64, y =-2738.55, z = 20.02, rotation = 330.29, NetworkSync = false}
