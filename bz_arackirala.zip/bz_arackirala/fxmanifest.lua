fx_version 'adamant'

game 'gta5'

description 'ESX'

client_scripts {
	'@extendedmode/locale.lua',
	'config.lua',
	'c_arackirala.lua'
}

server_scripts {
	'@mysql-async/lib/MySQL.lua',
	'@extendedmode/locale.lua',
	'config.lua',
	's_arackirala.lua'
}


